package sk.stuba.fei.uim.oop.main;

public class Main {
    public static void main(String[] args) {

    }
}