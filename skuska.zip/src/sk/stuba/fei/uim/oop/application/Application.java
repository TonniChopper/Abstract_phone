package sk.stuba.fei.uim.oop.application;

public class Application {
    private String name;
    private boolean canInstall;
    private boolean startableFromLocked;

    public Application(String name, boolean canInstallApplication, boolean startableFromLockedScreen) {
        this.name = name;
        this.canInstall = canInstallApplication;
        this.startableFromLocked = startableFromLockedScreen;
    }

    public Application(String name) {
        this(name, false, false);
    }

    public String getName() {
        return name;
    }

    public boolean canInstallApplication() { // ci aplikacia sluzi na instalovanie dalsich aplikacii
        return canInstall;
    }

    public boolean startableFromLockedScreen() { // ci mozno spustit bez zadania hesla
        return startableFromLocked;
    }

    // doplnte metody equals a hashCode

    public boolean equals(Application obj) {
        if (obj == null) {
            return false;
        }
        if (obj.hashCode() == this.hashCode()) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.getName().hashCode();
    }

}
